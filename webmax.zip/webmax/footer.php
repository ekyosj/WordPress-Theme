<footer>
      <p>Copyright &copy; 2023</p>
    </footer>
    <?php wp_footer(); ?>
  </body>
</html>